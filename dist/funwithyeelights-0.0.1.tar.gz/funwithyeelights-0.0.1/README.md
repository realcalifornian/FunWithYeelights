Welcome to the FunWithYeelights package!

In this package, you'll find simple codes used effectively to mess with Yeelight bulbs in a multitude of ways

As a quick disclaimer, you must have a Yeelight at home in order for this package to serve a purpose AND make sure to change the IP address based on your specific Yeelight, as mine won't be the exact same as yours for obvious reasons.

Have fun!